namespace WPFRegisterStudent
{
    public class Course
    {
        public string Title { get; set; }

        public Course(string title)
        {
            this.Title = title;
        }

        public override string ToString()
        {
            return Title;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
                return false;

            Course c = (Course)obj;
            return this.Title == c.Title;
        }

        public override int GetHashCode()
        {
            return Title.GetHashCode();
        }
    }
}
