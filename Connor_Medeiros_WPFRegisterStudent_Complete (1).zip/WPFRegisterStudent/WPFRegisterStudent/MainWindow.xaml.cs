using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace WPFRegisterStudent
{
    public partial class MainWindow : Window
    {
        Course choice;
        List<Course> registeredCourses = new List<Course>();
        int totalCreditHours = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Course course1 = new Course("IT 145");
            Course course2 = new Course("IT 200");
            Course course3 = new Course("IT 201");
            Course course4 = new Course("IT 270");
            Course course5 = new Course("IT 315");
            Course course6 = new Course("IT 328");
            Course course7 = new Course("IT 330");

            this.comboBox.Items.Add(course1);
            this.comboBox.Items.Add(course2);
            this.comboBox.Items.Add(course3);
            this.comboBox.Items.Add(course4);
            this.comboBox.Items.Add(course5);
            this.comboBox.Items.Add(course6);
            this.comboBox.Items.Add(course7);

            this.textBox.Text = "";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (comboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a course to register.", "Error");
                return;
            }

            choice = (Course)comboBox.SelectedItem;

            if (registeredCourses.Contains(choice))
            {
                MessageBox.Show($"You are already registered for {choice.Title}.", "Error");
                return;
            }

            if (totalCreditHours + 3 > 9)
            {
                MessageBox.Show("Cannot register for more than 9 credit hours.", "Error");
                return;
            }

            registeredCourses.Add(choice);
            totalCreditHours += 3;

            textBox.Text = string.Join("\n", registeredCourses.Select(c => c.Title));
            textBox1.Text = totalCreditHours.ToString();

            MessageBox.Show($"Successfully registered for {choice.Title}.", "Success");
        }
    }
}
